import requests
from bs4 import BeautifulSoup
import pandas as pd

def get_transactions(identifier: str) -> pd.DataFrame:
    """
        Get transaction details based on identifier.

        Parameters:
        arg1 (str): Transaction identifier

        Returns:
        pd.DataFrame: Dataframe corresponding to values of the identifier
                      parameter

    """
    if type(identifier) != str:
        raise ValueError("Incorrect argument type. str required")
    try:
        res = requests.get(f"https://sdw-wsrest.ecb.europa.eu/service/data/BSI/"
                           f"{identifier}?detail=dataonly")
    except Exception as err:
        print(err)
    df_dict = get_parameters(res, {'TIME_PERIOD': 'generic:ObsDimension',
                                   'OBS_VALUE': {'generic:ObsValue': float}})
    df_dict['IDENTIFIER'] = identifier
    df = pd.DataFrame.from_dict(df_dict)
    cols = ['IDENTIFIER', 'TIME_PERIOD', 'OBS_VALUE']
    df = df[cols]
    return df


def get_symmetric_identifier(identifier: str, swap_components: dict[int, int]) -> str:
    """
        Get Symmetric identifier.

        Parameters:
        arg1 (str): Transaction identifier
        arg2 (dict): Dictionary containing index as key(int) to be swapped with\
                     index as value(int) in transaction identifier string

        Returns:
        str: String corresponding to swapped values of the identifier
                      parameter

    """
    if type(identifier) != str:
        raise ValueError("Incorrect argument type. str required")
    if type(swap_components) != dict:
        raise ValueError("Incorrect argument type. dict required")
    identifier_list = identifier.split('.')
    for k,v in swap_components.items():
        if type(k) != int or type(v) != int:
            raise ValueError("Incorrect argument type. int required")
        identifier_list[k], identifier_list[v] = identifier_list[v],identifier_list[k]
    swapped_id = '.'.join(identifier_list)
    return swapped_id


def get_asymmetries(identifier: str, swap_components: dict[int, int]) -> pd.DataFrame:
    """
        Get asymmetries details based on identifier.

        Function computes the symmetric counterpart of provided\
        identifier and computes difference between OBS values of provided\
        identifier and symmetric identifier

        Parameters:
        arg1 (str): Transaction identifier
        arg2 (dict): Dictionary containing index as key(int) to be swapped with\
                     index as value(int) in transaction identifier string

        Returns:
        pd.DataFrame: DataFrame containing columns TIME_PERIOD, PROVIDED_ID,\
                      SYMMETRIC_ID, DELTA: Absolute difference between OBS_VALUE
                      columns of the provided and symmetric identifier, for the same TIME_PERIOD

        """
    swapped_id = get_symmetric_identifier(identifier, swap_components)
    df_id = get_transactions(identifier)
    df_swap_id = get_transactions(swapped_id)
    df_delta = pd.merge(df_id, df_swap_id, how='inner', on=['TIME_PERIOD'])
    df_delta.rename(columns={'IDENTIFIER_x': 'PROVIDED_ID', 'IDENTIFIER_y': 'SYMMETRIC_ID'},inplace=True)
    df_delta['DELTA'] = abs(df_delta['OBS_VALUE_x'] - df_delta['OBS_VALUE_y'])
    df_delta.drop(columns=['OBS_VALUE_x','OBS_VALUE_y'],inplace=True)
    cols = ['TIME_PERIOD', 'PROVIDED_ID', 'SYMMETRIC_ID', 'DELTA']
    df_delta = df_delta[cols]
    return df_delta


def get_parameters(res,para_dict):
    """
        Get dictionary with key as column name and value as list of values required from xml element.

        Parameters:
        arg1 (str): Http response from the url
        arg2 (dict): Key as required column name and value as required element from Http response

        Returns:
        dict: dictionary with key as column name and value as list of values required from xml element

    """
    soup = BeautifulSoup(res.content, 'xml')
    df_dict = {}
    for col,val in para_dict.items():
        conv = ''
        if type(val) == dict:
            for entry,data_type in val.items():
                conv = data_type
        fetch_val_list = soup.findAll(val)
        if conv == '':
            df_dict[col] = [item.get('value') for item in fetch_val_list]
        else:
            df_dict[col] = [conv(item.get('value')) for item in fetch_val_list]
    return df_dict
