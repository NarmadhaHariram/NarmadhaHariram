import requests
from bs4 import BeautifulSoup
import pandas as pd
import re


def get_transactions(identifier: str) -> pd.DataFrame:
    """
        Get transaction details based on identifier.

        Parameters:
        arg1 (str): Transaction identifier

        Returns:
        pd.DataFrame: Dataframe corresponding to values of the identifier
                      parameter

    """
    if type(identifier) != str:
        raise ValueError("Incorrect argument type. str required")
    try:
        res = requests.get(f"https://sdw-wsrest.ecb.europa.eu/service/data/BP6/"
                           f"{identifier}?detail=dataonly")
    except Exception as err:
        print(err)
    df_dict = get_parameters(res, {'TIME_PERIOD': 'generic:ObsDimension',
                                    'OBS_VALUE': {'generic:ObsValue': float}})
    df_dict['IDENTIFIER'] = identifier

    df = pd.DataFrame.from_dict(df_dict)
    cols = ['IDENTIFIER', 'TIME_PERIOD', 'OBS_VALUE']
    df = df[cols]
    return df


def get_formula_data(formula: str) -> pd.DataFrame:
    """
       Get formula data based on formula.

       Parameters:
       arg1 (str): Formula

       Returns:
       pd.DataFrame: Dataframe has as many columns as there are
                     identifiers in the right hand side of formula, each containing respective OBS_VALUE

   """
    if type(formula) != str:
        raise ValueError("Incorrect argument type. str required")
    formula = re.sub(r'\s+', '', formula)
    formula_list = formula.split('=')
    formula_right = formula_list[1]
    formula_add_sub = re.split('-|\+',formula_right)

    df_dict = {}
    for item in formula_add_sub:
        df = get_transactions(item)
        for index,sris in df.iterrows():
            time_per = df.loc[index,'TIME_PERIOD']
            dict_time = {}
            dict_time['TIME_PERIOD'] = time_per
            if time_per not in df_dict:
                df_dict[time_per] = dict_time
            id_dict = {}
            id_dict[df.loc[index,'IDENTIFIER']] = df.loc[index,'OBS_VALUE']
            df_dict[time_per].update(id_dict)
    df_val = list(df_dict.values())
    df_transformed = pd.DataFrame(df_val)
    df_transformed.fillna(0)
    return df_transformed


def compute_aggregates(formula: str) -> pd.DataFrame :
    """
       Compute aggregates data based on formula.

       Parameters:
       arg1 (str): Formula

       Returns:
       pd.DataFrame: Dataframe has a column named as identifier in the left
                     hand side of formula, containing value as evaluated expression in formula

    """
    if type(formula) != str:
        raise ValueError("Incorrect argument type. str required")
    df = get_formula_data(formula)
    formula = re.sub(r'\s+', '', formula)
    formula_list = formula.split('=')
    formula_right = formula_list[1]
    formula_add_sub = re.split('-|\+', formula_right)
    formula = formula.replace('.','__')
    df.columns = df.columns.str.replace(".", "__")
    df.eval(formula,inplace=True)
    df.columns = df.columns.str.replace("__", ".")
    df.drop(columns=formula_add_sub,inplace=True)
    return df


def get_parameters(res,para_dict):
    """
        Get dictionary with key as column name and value as list of values required from xml element.

        Parameters:
        arg1 (str): Http response from the url
        arg2 (dict): Key as required column name and value as required element from Http response

        Returns:
        dict: dictionary with key as column name and value as list of values required from xml element

    """
    soup = BeautifulSoup(res.content, 'xml')
    df_dict = {}
    for col,val in para_dict.items():
        conv = ''
        if type(val) == dict:
            for entry,data_type in val.items():
                conv = data_type
        fetch_val_list = soup.findAll(val)
        if conv == '':
            df_dict[col] = [item.get('value') for item in fetch_val_list]
        else:
            df_dict[col] = [conv(item.get('value')) for item in fetch_val_list]
    return df_dict



