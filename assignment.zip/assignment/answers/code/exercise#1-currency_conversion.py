import requests
from bs4 import BeautifulSoup
import pandas as pd

def get_exchange_rate(source_curr: str, target: str = "EUR") -> pd.DataFrame:
    """
        Get exchange rate.

        Parameters:
        arg1 (str): Source currency
        arg2 (str): Target currency

        Returns:
        pd.DataFrame: Dataframe containing exchange rates with time period

    """
    if type(source_curr) != str or type(target) != str:
        raise ValueError("Incorrect argument type. str required")
    try:
        res = requests.get(f"https://sdw-wsrest.ecb.europa.eu/service/data/EXR/M.{source_curr}."
                           f"{target}.SP00.A?detail=dataonly")
    except Exception as err:
        print(err)
    df_dict = get_parameters(res,{'TIME_PERIOD': 'generic:ObsDimension','OBS_VALUE': {'generic:ObsValue': float}})
    df = pd.DataFrame.from_dict(df_dict)
    return df


def get_raw_data(identifier: str) -> pd.DataFrame:
    """
        Get raw data.

        Parameters:
        arg1 (str): Transaction Identifier

        Returns:
        pd.DataFrame: Dataframe containing data corresponding to given identifier

    """
    if type(identifier) != str:
        raise ValueError("Incorrect argument type. str required")
    try:
        res = requests.get(f"https://sdw-wsrest.ecb.europa.eu/service/data/BP6/{identifier}?"
                           f"detail=dataonly")
    except Exception as err:
        print(err)
    df_dict = get_parameters(res, {'TIME_PERIOD': 'generic:ObsDimension', 'OBS_VALUE': {'generic:ObsValue': float}})
    df = pd.DataFrame.from_dict(df_dict)
    return df


def get_data(identifier: str, target_currency = None) -> pd.DataFrame:
    """
        Get data based on identifier and target currency.

        Parameters:
        arg1 (str): Transaction Identifier
        arg1 (str)(optional): Target currency

        Returns:
        pd.DataFrame: If target currency is not None then DataFrame contains OBS value
                      of data of target currency else contains OBS value of source currency from identifier

    """
    if type(identifier) != str:
        raise ValueError("Incorrect argument type. str required")
    if target_currency is None:
        df = get_raw_data(identifier)
    else:
        if type(target_currency) != str:
            raise ValueError("Incorrect argument type. str required")
        source_curr = identifier.split('.')[12]
        df = get_exchange_rate(source_curr, target_currency)
    return df

def get_parameters(res,para_dict):
    """
        Get dictionary with key as column name and value as list of values required from xml element.

        Parameters:
        arg1 (str): Http response from the url
        arg2 (dict): Key as required column name and value as required element from Http response

        Returns:
        dict: dictionary with key as column name and value as list of values required from xml element

    """
    soup = BeautifulSoup(res.content, 'xml')
    df_dict = {}
    for col,val in para_dict.items():
        conv = ''
        if type(val) == dict:
            for entry,data_type in val.items():
                conv = data_type
        fetch_val_list = soup.findAll(val)
        if conv == '':
            df_dict[col] = [item.get('value') for item in fetch_val_list]
        else:
            df_dict[col] = [conv(item.get('value')) for item in fetch_val_list]
    return df_dict



