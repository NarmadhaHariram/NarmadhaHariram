import currency_conversion as cc
import pandas as pd
import unittest as ut

def test_get_exchange_rate():
    assert type(cc.get_exchange_rate("GBP","EUR")) == pd.DataFrame
    df = cc.get_exchange_rate("GBP","EUR")
    assert df.columns.tolist() == ['TIME_PERIOD', 'OBS_VALUE']
    assert df.loc[0,'OBS_VALUE'] == 0.7029125

def test_get_exchange_rate_negative():
    try:
        cc.get_exchange_rate("GBP",1)
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)


def test_get_raw_data():
    assert type(cc.get_raw_data('M.N.I8.W1.S1.S1.T.N.FA.F.F7.T.EUR._T.T.N')) == pd.DataFrame
    df = cc.get_raw_data('M.N.I8.W1.S1.S1.T.N.FA.F.F7.T.EUR._T.T.N')
    assert df.columns.tolist() == ['TIME_PERIOD', 'OBS_VALUE']
    assert df.loc[0, 'OBS_VALUE'] == 1427.66666666667

def test_get_raw_data_negative():
    try:
        cc.get_raw_data(1)
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)

def test_get_data():
    assert type(cc.get_data('M.N.I8.W1.S1.S1.T.N.FA.F.F7.T.EUR._T.T.N')) == pd.DataFrame
    df = cc.get_data("M.N.I8.W1.S1.S1.T.N.FA.F.F7.T.EUR._T.T.N", "GBP")
    assert df.empty

def test_get_data_negative():
    try:
        cc.get_data(1)
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)
