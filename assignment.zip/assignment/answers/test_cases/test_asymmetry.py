import asymmetry_check as ac
import pandas as pd

def test_get_transactions():
    assert type(ac.get_transactions("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N")) == pd.DataFrame
    df = ac.get_transactions("Q.DE.N.A.A20.A.1.AT.2000.Z01.E")
    assert df.columns.tolist() == ['IDENTIFIER', 'TIME_PERIOD', 'OBS_VALUE']
    assert df.loc[0, 'OBS_VALUE'] == 14001.0

def test_get_transactions_negative():
    try:
        ac.get_transactions(1)
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)

def test_get_symmetric_identifier():
    assert type(ac.get_symmetric_identifier("Q.HR.N.A.A20.A.1.AT.2000.Z01.E", {1: 7, 2: 3})) == str
    sym_string = ac.get_symmetric_identifier("Q.HR.N.A.A20.A.1.AT.2000.Z01.E", {1: 7, 2: 3})
    assert sym_string == 'Q.AT.A.N.A20.A.1.HR.2000.Z01.E'

def test_get_symmetric_identifier_negative():
    try:
        ac.get_symmetric_identifier(1,{7 : 1})
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)

def test_get_transactions_negative():
    try:
        ac.get_transactions(1)
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)

def test_get_asymmetries():
    assert type(ac.get_asymmetries("Q.HR.N.A.A20.A.1.AT.2000.Z01.E", {1: 7})) == pd.DataFrame
    df = ac.get_asymmetries("Q.HR.N.A.A20.A.1.AT.2000.Z01.E", {1: 7})
    assert df.columns.tolist() == ['TIME_PERIOD', 'PROVIDED_ID', 'SYMMETRIC_ID', 'DELTA']
    assert df.loc[0, 'DELTA'] == 8866.696899662522

def test_get_asymmetries_negative():
    try:
        ac.get_asymmetries(1,{1: 7})
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)