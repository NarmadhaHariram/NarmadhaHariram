import aggregations as ag
import pandas as pd

def test_get_transactions():
    assert type(ag.get_transactions("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N")) == pd.DataFrame
    df = ag.get_transactions("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N")
    assert df.columns.tolist() == ['IDENTIFIER', 'TIME_PERIOD', 'OBS_VALUE']
    assert df.loc[0, 'OBS_VALUE'] == 55420.1818623299

def test_get_transactions_negative():
    try:
        ag.get_transactions(1)
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)


def test_get_formula_data():
    assert type(ag.get_formula_data("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N=\
                                    Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N+\
                                    Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N")) == pd.DataFrame
    df = ag.get_formula_data("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N=\
                                    Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N+\
                                    Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N")
    assert df.columns.tolist() == ['TIME_PERIOD',
                                    'Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N',
                                    'Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N']
    assert df.loc[0, 'Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N'] == 158849.702543074

def test_get_formula_data_negative():
    try:
        ag.get_formula_data(1)
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)

def test_compute_aggregates():
    assert type(ag.compute_aggregates("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N =\
                                       Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N +\
                                       Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N")) == pd.DataFrame
    df = ag.compute_aggregates("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N =\
                                       Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N +\
                                       Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N")
    assert df.columns.tolist() == ['TIME_PERIOD',
                                   'Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N']
    assert df.loc[0, 'Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N'] == 317663.447909148


def test_compute_aggregates_negative():
    try:
        ag.compute_aggregates(1)
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'Incorrect argument type. str required' in str(e)