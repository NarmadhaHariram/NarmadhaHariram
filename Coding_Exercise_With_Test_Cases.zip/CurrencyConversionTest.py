import unittest
from currency_conversion_oops import CurrencyConversion
import pandas as pd

class CurrencyConversionCase(unittest.TestCase):

    def test_get_exchange_rate(self):
        currency_conversion = CurrencyConversion("M.N.I8.W1.S1.S1.T.N.FA.F.F7.T.EUR._T.T.N", "GBP")
        data = currency_conversion.get_exchange_rate()
        result = data[(data.TIME_PERIOD == '1999-01') | (data.TIME_PERIOD == '1999-02')]
        expected = pd.DataFrame({'TIME_PERIOD': ['1999-01','1999-02'], 'OBS_VALUE': [0.702913, 0.688505]})
        pd.util.testing.assert_frame_equal(result, expected)  # add assertion here

    def test_get_raw_data(self):
        currency_conversion = CurrencyConversion("M.N.I8.W1.S1.S1.T.N.FA.F.F7.T.EUR._T.T.N", "GBP")
        data = currency_conversion.get_raw_data()
        result = data[(data.TIME_PERIOD == '1999-01') | (data.TIME_PERIOD == '1999-02')]
        expected = pd.DataFrame({'TIME_PERIOD': ['1999-01','1999-02'], 'OBS_VALUE': [1427.666667, 379.666667]})
        pd.util.testing.assert_frame_equal(result, expected)  # add assertion here

    def test_result(self):
        currency_conversion = CurrencyConversion("M.N.I8.W1.S1.S1.T.N.FA.F.F7.T.EUR._T.T.N", "GBP")
        data = currency_conversion.get_data()
        result = data[(data.TIME_PERIOD == '1999-01') | (data.TIME_PERIOD == '1999-02')]
        expected = pd.DataFrame({'TIME_PERIOD': ['1999-01','1999-02'], 'OBS_VALUE': [1003.52546,261.402399]})
        pd.util.testing.assert_frame_equal(result, expected)  # add assertion here

if __name__ == '__main__':
    unittest.main()
