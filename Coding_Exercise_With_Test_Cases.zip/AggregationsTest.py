import unittest
from aggregations_oops import Aggregations
import pandas as pd

class AggregationsCase(unittest.TestCase):

    def test_get_transactions(self):
        aggregations = Aggregations(
            "Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N = Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N + Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N")
        data = aggregations.get_transactions("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N")
        result = data[(data.TIME_PERIOD == '1999-Q1') | (data.TIME_PERIOD == '1999-Q2')]
        expected = pd.DataFrame({'TIME_PERIOD': ['1999-Q1', '1999-Q2'],
                                 'OBS_VALUE': [55420.181862, 87003.970961]})
        result['OBS_VALUE'] = result['OBS_VALUE'].round(6)
        pd.util.testing.assert_frame_equal(result, expected)

    def test_get_formula_data(self):
        aggregations = Aggregations(
            "Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N = Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N + Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N")
        data = aggregations.get_formula_data()
        result = data[(data.TIME_PERIOD == '2008-Q1') | (data.TIME_PERIOD == '2008-Q2')]
        expected = pd.DataFrame({'TIME_PERIOD': ['2008-Q1', '2008-Q2'],
                                 'Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N': [158849.702543, 55317.060368],
                                 'Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N': [158813.745366, 55136.813191]})
        pd.util.testing.assert_frame_equal(result, expected)

    def test_compute_aggregates(self):
        aggregations = Aggregations(
            "Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N = Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N + Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N")
        data = aggregations.compute_aggregates()
        result = data[(data.TIME_PERIOD == '2008-Q1') | (data.TIME_PERIOD == '2008-Q2')]
        expected = pd.DataFrame({'TIME_PERIOD': ['2008-Q1', '2008-Q2'],
                                 'Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N': [317663.447909, 110453.873559]})
        pd.util.testing.assert_frame_equal(result, expected)

if __name__ == '__main__':
    unittest.main()
