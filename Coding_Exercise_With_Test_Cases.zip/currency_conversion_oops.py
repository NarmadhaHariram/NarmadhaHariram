from io import StringIO
import requests
import xml.etree.ElementTree as ET
import pandas as pd

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)


class CurrencyConversion:
    def __init__(self, data_identifier, source_currency, target_currency="EUR"):
        self.data_identifier = data_identifier
        self.source_currency = source_currency
        self.target_currency = target_currency

    def get_webservice_data(self, url):
        response = requests.get(url)
        xml_data = response.text
        return xml_data

    def get_exchange_rate(self):
        url = "https://sdw-wsrest.ecb.europa.eu/service/data/EXR/M." + self.source_currency + "." + self.target_currency + ".SP00.A?detail=dataonly"
        xml_data = self.get_webservice_data(url)
        root = ET.fromstring(xml_data)
        my_namespaces = dict([node for _, node in ET.iterparse(StringIO(xml_data), events=['start-ns'])])
        obs = root.findall('.//generic:Obs', namespaces=my_namespaces)
        month = []
        value = []
        raw_data = pd.DataFrame()
        _month_value = {}
        for a in obs:
            for b in a.findall('.//generic:ObsDimension', namespaces=my_namespaces):
                month.append((b.attrib['value']))
            for b in a.findall('.//generic:ObsValue', namespaces=my_namespaces):
                value.append((b.attrib['value']))
        if month and value:
            _month_value = {'TIME_PERIOD': month, 'OBS_VALUE': value}
        raw_data = pd.DataFrame.from_dict(_month_value)
        raw_data["OBS_VALUE"] = raw_data["OBS_VALUE"].astype("float")
        return raw_data

    def get_raw_data(self):
        url = 'https://sdw-wsrest.ecb.europa.eu/service/data/BP6/' + self.data_identifier + '?detail=dataonly'
        xml_data = self.get_webservice_data(url)
        root = ET.fromstring(xml_data)
        my_namespaces = dict([node for _, node in ET.iterparse(StringIO(xml_data), events=['start-ns'])])
        obs = root.findall('.//generic:Obs', namespaces=my_namespaces)
        month = []
        value = []
        raw_data = pd.DataFrame()
        _month_value = {}
        for a in obs:
            for b in a.findall('.//generic:ObsDimension', namespaces=my_namespaces):
                month.append((b.attrib['value']))
            for b in a.findall('.//generic:ObsValue', namespaces=my_namespaces):
                value.append((b.attrib['value']))
        if month and value:
            _month_value = {'TIME_PERIOD': month, 'OBS_VALUE': value}
        raw_data = pd.DataFrame.from_dict(_month_value)
        raw_data["OBS_VALUE"] = raw_data["OBS_VALUE"].astype("float")
        return raw_data

    def get_data(self):
        raw_data = pd.DataFrame()
        try:
            raw_data = self.get_raw_data()

        except Exception as ex:
            print("Invalid Identifier!!!")
        exchange = pd.DataFrame()
        if self.source_currency:
            try:
                exchange = self.get_exchange_rate()
            except Exception as ex:
                print("Invalid Currency!!!")
            exchange = exchange.rename({'OBS_VALUE': 'currency_multiplier'}, axis='columns')
            raw_data = pd.merge(exchange, raw_data, how='inner', on='TIME_PERIOD')
            raw_data['OBS_VALUE'] = raw_data["currency_multiplier"] * raw_data["OBS_VALUE"]
        if len(raw_data):
            return raw_data[['TIME_PERIOD','OBS_VALUE']]
        return raw_data


if __name__ == '__main__':
    currency_conversion = CurrencyConversion("M.N.I8.W1.S1.S1.T.N.FA.F.F7.T.EUR._T.T.N", "GBP")
    data = currency_conversion.get_data()
    #data = data[(data.TIME_PERIOD == '1999-01') | (data.TIME_PERIOD == '1999-02')]
    print(data)
    #print(currency_conversion.get_data())
