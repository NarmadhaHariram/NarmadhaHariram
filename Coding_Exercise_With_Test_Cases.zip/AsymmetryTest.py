import unittest
from asymmetry_check_oops import AsymmetryCheck
import pandas as pd

class AsymmetryCheckCase(unittest.TestCase):

    def test_get_transactions(self):
        asymmetry_check = AsymmetryCheck("Q.HR.N.A.A20.A.1.AT.2000.Z01.E", {1: 7})
        data = asymmetry_check.get_transactions("Q.DE.N.A.A20.A.1.AT.2000.Z01.E")
        result = data[(data.TIME_PERIOD == '2012-Q2') | (data.TIME_PERIOD == '2012-Q3')]
        expected = pd.DataFrame({'TIME_PERIOD': ['2012-Q2', '2012-Q3'],
                                 'OBS_VALUE': [14001.0, 13568.0]})
        expected["OBS_VALUE"] = expected["OBS_VALUE"].astype("float")
        pd.util.testing.assert_frame_equal(result, expected)

    def test_get_symmetric_identifier(self):
        asymmetry_check = AsymmetryCheck("Q.HR.N.A.A20.A.1.AT.2000.Z01.E", {1: 7, 2: 3})
        swapped_identifier = asymmetry_check.get_symmetric_identifier()
        expected = 'Q.AT.A.N.A20.A.1.HR.2000.Z01.E'
        message = "Symmetric Identified constructed as expected"
        self.assertEqual(swapped_identifier, expected, message)

    def test_get_asymmetries(self):
        asymmetry_check = AsymmetryCheck("Q.HR.N.A.A20.A.1.AT.2000.Z01.E", {1: 7})
        data = asymmetry_check.get_asymmetries()
        result = data[(data.TIME_PERIOD == '2014-Q1') | (data.TIME_PERIOD == '2014-Q2')]
        # In this testing code i changed expected value from 9036.292580 to 9036.292579 because it is wrong in PDF
        expected = pd.DataFrame({'TIME_PERIOD': ['2014-Q1', '2014-Q2'],
                                 'PROVIDED_ID': ['Q.HR.N.A.A20.A.1.AT.2000.Z01.E', 'Q.HR.N.A.A20.A.1.AT.2000.Z01.E'],
                                 'SYMMETRIC_ID': ['Q.AT.N.A.A20.A.1.HR.2000.Z01.E', 'Q.AT.N.A.A20.A.1.HR.2000.Z01.E'],
                                 'DELTA': [9036.292579, 8809.512144]})
        result = result.reset_index(drop=True)
        pd.util.testing.assert_frame_equal(result, expected)

if __name__ == '__main__':
    unittest.main()
