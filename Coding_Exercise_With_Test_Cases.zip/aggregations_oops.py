from io import StringIO
import requests
import xml.etree.ElementTree as ET
import pandas as pd

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)


class Aggregations:
    def __init__(self, formula):
        formula = formula.split("=")
        self.transaction_data_identifier = formula[0].strip()
        formula = formula[1].split("+")
        self.data_identifier_1 = formula[0].strip()
        self.data_identifier_2 = formula[1].strip()

    def get_webservice_data(self, url):
        response = requests.get(url)
        xml_data = response.text
        return xml_data

    def get_transactions(self, data_identifier):
        url = 'https://sdw-wsrest.ecb.europa.eu/service/data/BP6/' + data_identifier + '?detail=dataonly'
        xml_data = self.get_webservice_data(url)
        root = ET.fromstring(xml_data)
        my_namespaces = dict([node for _, node in ET.iterparse(StringIO(xml_data), events=['start-ns'])])
        obs = root.findall('.//generic:Obs', namespaces=my_namespaces)
        month = []
        value = []
        raw_data = pd.DataFrame()
        _month_value = {}
        for a in obs:
            for b in a.findall('.//generic:ObsDimension', namespaces=my_namespaces):
                month.append((b.attrib['value']))
            for b in a.findall('.//generic:ObsValue', namespaces=my_namespaces):
                value.append((b.attrib['value']))
        if month and value:
            _month_value = {'TIME_PERIOD': month, 'OBS_VALUE': value}
        raw_data = pd.DataFrame.from_dict(_month_value)
        raw_data["OBS_VALUE"] = raw_data["OBS_VALUE"].astype("float")
        return raw_data

    def get_formula_data(self):
        formula_data = pd.DataFrame()
        try:
            formula_data_1_data = self.get_transactions(self.data_identifier_1)
            formula_data_2_data = self.get_transactions(self.data_identifier_2)
            formula_data_1_data = formula_data_1_data.rename({'OBS_VALUE': self.data_identifier_1},
                                                             axis='columns')
            formula_data_2_data = formula_data_2_data.rename({'OBS_VALUE': self.data_identifier_2},
                                                             axis='columns')
        except Exception as ex:
            print("Invalid Identifier!!!")
        formula_data = pd.merge(formula_data_1_data, formula_data_2_data, how='inner', on='TIME_PERIOD')
        return formula_data

    def compute_aggregates(self):
        formula_data = self.get_formula_data()
        formula_data[self.transaction_data_identifier] = formula_data[self.data_identifier_1] + formula_data[
            self.data_identifier_2]
        return formula_data[['TIME_PERIOD', self.transaction_data_identifier]]


if __name__ == '__main__':
    aggregations = Aggregations("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N = Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N + Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N")
    data = aggregations.compute_aggregates()
    #data = data[(data.TIME_PERIOD == '2008-Q1') | (data.TIME_PERIOD == '2008-Q2')]
    print(data)
