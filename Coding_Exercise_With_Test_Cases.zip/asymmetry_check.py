from io import StringIO
import requests
import xml.etree.ElementTree as ET
import pandas as pd

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)


def _get_data(url):
    response = requests.get(url)
    xml_data = response.text
    return xml_data


def get_transactions(data_identifier):
    url = 'https://sdw-wsrest.ecb.europa.eu/service/data/BSI/' + data_identifier + '?detail=dataonly'
    xml_data = _get_data(url)
    root = ET.fromstring(xml_data)
    my_namespaces = dict([node for _, node in ET.iterparse(StringIO(xml_data), events=['start-ns'])])
    obs = root.findall('.//generic:Obs', namespaces=my_namespaces)
    month = []
    value = []
    for a in obs:
        for b in a.findall('.//generic:ObsDimension', namespaces=my_namespaces):
            month.append((b.attrib['value']))
        for b in a.findall('.//generic:ObsValue', namespaces=my_namespaces):
            value.append((b.attrib['value']))

    _month_value = {'TIME_PERIOD': month, 'OBS_VALUE': value}
    df = pd.DataFrame.from_dict(_month_value)
    df["OBS_VALUE"] = df["OBS_VALUE"].astype("float")
    return df


def get_symmetric_identifier(data_identifier, _swap_dict):
    data_identifier_split = data_identifier.split(".")
    for key, value in _swap_dict.items():
        temp = data_identifier_split[key]
        data_identifier_split[key] = data_identifier_split[value]
        data_identifier_split[value] = temp
    swapped_identifier = ".".join(data_identifier_split)
    print(swapped_identifier)
    return swapped_identifier


def get_asymmetries(data_identifier, _swap_dict):
    try:
        provided_transaction_data = get_transactions(data_identifier)
        provided_transaction_data = provided_transaction_data.rename({'OBS_VALUE': 'provided_obs'}, axis='columns')
        sym_data_identifier = get_symmetric_identifier(data_identifier,_swap_dict)
        symmetric_transaction_data = get_transactions(sym_data_identifier)
        symmetric_transaction_data = symmetric_transaction_data.rename({'OBS_VALUE': 'symmetric_obs'}, axis='columns')
        provided_transaction_data['PROVIDED_ID'] = [data_identifier for i in
                                                    range(len(provided_transaction_data))]
        symmetric_transaction_data['SYMMETRIC_ID'] = [sym_data_identifier for i in
                                                      range(len(symmetric_transaction_data))]
        print(provided_transaction_data)
        print(symmetric_transaction_data)
    except Exception as ex:
        print("Invalid Identifier!!!")

    raw_data = pd.merge(provided_transaction_data, symmetric_transaction_data, how='inner', on='TIME_PERIOD')
    raw_data["DELTA"] = abs(raw_data.provided_obs - raw_data.symmetric_obs)
    raw_data = raw_data[raw_data['provided_obs'].notnull() & raw_data['symmetric_obs'].notnull()]
    return raw_data[['TIME_PERIOD', 'PROVIDED_ID', 'SYMMETRIC_ID', 'DELTA']]


if __name__ == '__main__':
    final_data = get_asymmetries("Q.HR.N.A.A20.A.1.AT.2000.Z01.E", {1: 7})
    print(final_data)

