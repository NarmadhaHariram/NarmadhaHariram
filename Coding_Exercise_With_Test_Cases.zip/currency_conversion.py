from io import StringIO
import requests
import xml.etree.ElementTree as ET
import pandas as pd

'''This method will get response from the URL passed.
In this case it will be XML data'''


def _get_data(url):
    response = requests.get(url)
    xml_data = response.text
    return xml_data


'''This method will take source and target_currency'''


def get_exchange_rate(source_currency, target_currency="EUR"):
    url = "https://sdw-wsrest.ecb.europa.eu/service/data/EXR/M." + source_currency + "." + target_currency + ".SP00.A?detail=dataonly"
    xml_data = _get_data(url)
    root = ET.fromstring(xml_data)
    my_namespaces = dict([node for _, node in ET.iterparse(StringIO(xml_data), events=['start-ns'])])
    obs = root.findall('.//generic:Obs', namespaces=my_namespaces)
    month = []
    value = []
    for a in obs:
        for b in a.findall('.//generic:ObsDimension', namespaces=my_namespaces):
            month.append((b.attrib['value']))
        for b in a.findall('.//generic:ObsValue', namespaces=my_namespaces):
            value.append((b.attrib['value']))

    _month_value = {'TIME_PERIOD': month, 'OBS_VALUE': value}
    df = pd.DataFrame.from_dict(_month_value)
    return df


'''This method will take user specified identifier as input to fetch data from European Central Bank'''


def get_raw_data(data_identifier):
    url = 'https://sdw-wsrest.ecb.europa.eu/service/data/BP6/'+data_identifier+'?detail=dataonly'
    xml_data = _get_data(url)
    root = ET.fromstring(xml_data)
    my_namespaces = dict([node for _, node in ET.iterparse(StringIO(xml_data), events=['start-ns'])])
    obs = root.findall('.//generic:Obs', namespaces=my_namespaces)
    month = []
    value = []
    for a in obs:
        for b in a.findall('.//generic:ObsDimension', namespaces=my_namespaces):
            month.append((b.attrib['value']))
        for b in a.findall('.//generic:ObsValue', namespaces=my_namespaces):
            value.append((b.attrib['value']))

    _month_value = {'TIME_PERIOD': month, 'OBS_VALUE': value}
    df = pd.DataFrame.from_dict(_month_value)
    return df


'''This method will take user specified identifier as input to fetch data from European Central Bank and target currency
And will return the final value as a dataframe'''


def get_data(data_identifier, currency):
    try:
        raw_data = get_raw_data(data_identifier)
        raw_data["OBS_VALUE"] = raw_data["OBS_VALUE"].astype("float")
    except Exception as ex:
        print("Invalid Identifier!!!")

    if currency:
        try:
            exchange = get_exchange_rate(currency)
        except Exception as ex:
            print("Invalid Currency!!!")
        exchange = exchange.rename({'OBS_VALUE': 'currency_multiplier'}, axis='columns')
        exchange["currency_multiplier"] = exchange["currency_multiplier"].astype("float")
        raw_data = pd.merge(exchange, raw_data, how='inner', on='TIME_PERIOD')
        raw_data['OBS_VALUE'] = raw_data["currency_multiplier"] * raw_data["OBS_VALUE"]

    return raw_data[['TIME_PERIOD','OBS_VALUE']]
    

if __name__ == '__main__':
    final_data = get_data("M.N.I8.W1.S1.S1.T.N.FA.F.F7.T.EUR._T.T.N", "GBP")
    print(final_data)
