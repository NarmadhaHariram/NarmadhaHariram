This script requires below libraries
io
requests
xml.etree.ElementTree
pandas

Copy this file in pyCharm or any path make sure all the libraries mentioned are imported
Execute directly in pycharm inside a project