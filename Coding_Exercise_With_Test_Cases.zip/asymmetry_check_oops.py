from io import StringIO
import requests
import xml.etree.ElementTree as ET
import pandas as pd

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)


class AsymmetryCheck:
    def __init__(self, data_identifier, swapper):
        self.data_identifier = data_identifier
        self.swapper = swapper

    def get_webservice_data(self, url):
        response = requests.get(url)
        xml_data = response.text
        return xml_data

    def get_transactions(self, data_identifier):
        url = 'https://sdw-wsrest.ecb.europa.eu/service/data/BSI/' + data_identifier + '?detail=dataonly'
        xml_data = self.get_webservice_data(url)
        root = ET.fromstring(xml_data)
        my_namespaces = dict([node for _, node in ET.iterparse(StringIO(xml_data), events=['start-ns'])])
        obs = root.findall('.//generic:Obs', namespaces=my_namespaces)
        month = []
        value = []
        raw_data = pd.DataFrame()
        _month_value = {}
        for a in obs:
            for b in a.findall('.//generic:ObsDimension', namespaces=my_namespaces):
                month.append((b.attrib['value']))
            for b in a.findall('.//generic:ObsValue', namespaces=my_namespaces):
                value.append((b.attrib['value']))
        if month and value:
            _month_value = {'TIME_PERIOD': month, 'OBS_VALUE': value}
        raw_data = pd.DataFrame.from_dict(_month_value)
        raw_data["OBS_VALUE"] = raw_data["OBS_VALUE"].astype("float")
        return raw_data

    def get_symmetric_identifier(self):
        data_identifier_split = self.data_identifier.split(".")
        for key, value in self.swapper.items():
            temp = data_identifier_split[key]
            data_identifier_split[key] = data_identifier_split[value]
            data_identifier_split[value] = temp
        swapped_identifier = ".".join(data_identifier_split)
        return swapped_identifier

    def get_asymmetries(self):
        raw_data = pd.DataFrame()
        try:
            provided_transaction_data = self.get_transactions(self.data_identifier)
            provided_transaction_data = provided_transaction_data.rename({'OBS_VALUE': 'provided_obs'}, axis='columns')
            sym_data_identifier = self.get_symmetric_identifier()
            symmetric_transaction_data = self.get_transactions(sym_data_identifier)
            symmetric_transaction_data = symmetric_transaction_data.rename({'OBS_VALUE': 'symmetric_obs'},
                                                                           axis='columns')
            provided_transaction_data['PROVIDED_ID'] = [self.data_identifier for i in
                                                        range(len(provided_transaction_data))]
            symmetric_transaction_data['SYMMETRIC_ID'] = [sym_data_identifier for i in
                                                          range(len(symmetric_transaction_data))]
        except Exception as ex:
            print("Invalid Identifier!!!")
        raw_data = pd.merge(provided_transaction_data, symmetric_transaction_data, how='inner', on='TIME_PERIOD')
        raw_data["DELTA"] = abs(raw_data.provided_obs - raw_data.symmetric_obs)
        raw_data = raw_data[raw_data['provided_obs'].notnull() & raw_data['symmetric_obs'].notnull()]
        return raw_data[['TIME_PERIOD', 'PROVIDED_ID', 'SYMMETRIC_ID', 'DELTA']]


if __name__ == '__main__':
    asymmetric_check = AsymmetryCheck("Q.HR.N.A.A20.A.1.AT.2000.Z01.E", {1: 7})
    data = asymmetric_check.get_asymmetries()
    data = data[(data.TIME_PERIOD == '2014-Q1') | (data.TIME_PERIOD == '2014-Q2')]
    print(data)
    #print(currency_conversion.get_data())
