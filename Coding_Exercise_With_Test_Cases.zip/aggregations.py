from io import StringIO
import requests
import xml.etree.ElementTree as ET
import pandas as pd

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', -1)


def _get_data(url):
    response = requests.get(url)
    xml_data = response.text
    return xml_data


def get_transactions(data_identifier):
    url = 'https://sdw-wsrest.ecb.europa.eu/service/data/BP6/' + data_identifier + '?detail=dataonly'
    xml_data = _get_data(url)
    root = ET.fromstring(xml_data)
    my_namespaces = dict([node for _, node in ET.iterparse(StringIO(xml_data), events=['start-ns'])])
    obs = root.findall('.//generic:Obs', namespaces=my_namespaces)
    month = []
    value = []
    for a in obs:
        for b in a.findall('.//generic:ObsDimension', namespaces=my_namespaces):
            month.append((b.attrib['value']))
        for b in a.findall('.//generic:ObsValue', namespaces=my_namespaces):
            value.append((b.attrib['value']))

    _month_value = {'TIME_PERIOD': month, 'OBS_VALUE': value}
    df = pd.DataFrame.from_dict(_month_value)
    df["OBS_VALUE"] = df["OBS_VALUE"].astype("float")
    return df


def get_formula_data(formula):
    formula = formula.split("+")
    formula_data_1_data_identifier = formula[0].strip()
    formula_data_2_data_identifier = formula[1].strip()
    formula_data = None
    try:
        formula_data_1_data = get_transactions(formula_data_1_data_identifier)
        formula_data_2_data = get_transactions(formula_data_2_data_identifier)
        formula_data_1_data = formula_data_1_data.rename({'OBS_VALUE': formula_data_1_data_identifier}, axis='columns')
        formula_data_2_data = formula_data_2_data.rename({'OBS_VALUE': formula_data_2_data_identifier}, axis='columns')
    except Exception as ex:
        print("Invalid Identifier!!!")
    formula_data = pd.merge(formula_data_1_data, formula_data_2_data, how='inner', on='TIME_PERIOD')
    print(formula_data)
    return formula_data


def compute_aggregates(formula):
    formula = formula.split("=")
    transaction_data_identifier = formula[0].strip()
    formula_data = get_formula_data(formula[1].strip())
    formula = formula[1].split("+")
    formula_data_1_data_identifier = formula[0].strip()
    formula_data_2_data_identifier = formula[1].strip()
    formula_data[transaction_data_identifier] = formula_data[formula_data_1_data_identifier] + formula_data[
        formula_data_2_data_identifier]
    return formula_data[['TIME_PERIOD', transaction_data_identifier]]


if __name__ == '__main__':
    final_data = compute_aggregates("Q.N.I8.W1.S1.S1.T.A.FA.D.F._Z.EUR._T._X.N = Q.N.I8.W1.S1P.S1.T.A.FA.D.F._Z.EUR._T._X.N + Q.N.I8.W1.S1Q.S1.T.A.FA.D.F._Z.EUR._T._X.N")
    print(final_data)

